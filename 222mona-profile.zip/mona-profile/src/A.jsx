import { useEffect, useMemo, useState } from 'react'

const motionVideos = [
	'https://cdn.coverr.co/videos/coverr-programming-code-on-a-screen-1573/1080p.mp4',
	'/media/mona-studio-reel.mp4',
	'https://media.w3.org/2010/05/bunny/trailer.mp4',
	'https://media.w3.org/2010/05/video/movie_300.mp4',
	'https://storage.googleapis.com/coverr-main/mp4/Mt_Baker.mp4',
	'https://storage.googleapis.com/coverr-main/mp4/Footboys.mp4',
]

const projects = [
	{ id: 'morrow', number: '01', title: 'Morrow', type: 'Product system', year: '2024', summary: 'A calmer command centre for teams shipping across time zones.', detail: 'I redesigned the handoff between signal, decision, and action for a distributed operations team.', result: '-38% time to first action', tags: ['React', 'Design systems', 'Product'], color: '#f26b55', shape: 'rings', media: 'https://images.unsplash.com/photo-1497366811353-6870744d04b2?auto=format&fit=crop&w=1200&q=85', video: motionVideos[0] },
	{ id: 'fieldnotes', number: '02', title: 'Fieldnotes', type: 'Digital archive', year: '2023', summary: 'A living research library turned into an experience people want to return to.', detail: 'An editorial archive with progressive disclosure, durable URLs, and a reading rhythm built for curiosity.', result: '+2.4x deeper sessions', tags: ['Next.js', 'Motion', 'CMS'], color: '#b7d4c0', shape: 'stack', media: 'https://images.unsplash.com/photo-1521587760476-6c12a4b040da?auto=format&fit=crop&w=1200&q=85', video: motionVideos[1] },
	{ id: 'trace', number: '03', title: 'Trace / 01', type: 'Data experience', year: '2023', summary: 'A visual language for making infrastructure feel human and legible.', detail: 'A real-time observability interface that helps non-technical teams see the story inside their systems.', result: '12k events / second', tags: ['D3', 'WebGL', 'Systems'], color: '#a8c6d5', shape: 'orbit', media: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=1200&q=85', video: motionVideos[2] },
	{ id: 'atlas', number: '04', title: 'Atlas', type: 'Travel platform', year: '2022', summary: 'A route-planning tool for people who prefer the long way around.', detail: 'I turned a dense map product into a tactile planning ritual with saved routes, smart waypoints, and a calmer decision surface.', result: '84% route completion', tags: ['React', 'Maps', 'UX research'], color: '#d9ef79', shape: 'rings', media: 'https://images.unsplash.com/photo-1500534623283-312aade485b7?auto=format&fit=crop&w=1200&q=85', video: motionVideos[3] },
	{ id: 'common-room', number: '05', title: 'Common Room', type: 'Community tool', year: '2022', summary: 'A gentle operating system for an ambitious creative community.', detail: 'A modular space for finding people, hosting conversations, and making the invisible work of belonging visible.', result: '3.1k active members', tags: ['Vue', 'Realtime', 'Content'], color: '#d59dc1', shape: 'stack', media: 'https://images.unsplash.com/photo-1529156069898-49953e39b3ac?auto=format&fit=crop&w=1200&q=85', video: motionVideos[4] },
	{ id: 'afterlight', number: '06', title: 'Afterlight', type: 'Brand experience', year: '2021', summary: 'A digital home for a studio making light do impossible things.', detail: 'A responsive visual identity that lets the studio work lead, while the navigation quietly gets out of its way.', result: '+61% qualified leads', tags: ['Webflow', 'Art direction', 'Motion'], color: '#e3b06c', shape: 'orbit', media: 'https://images.unsplash.com/photo-1497366754035-f200968a6e72?auto=format&fit=crop&w=1200&q=85', video: motionVideos[5] },
]

const filters = ['All', 'Product', 'Experiments']

function Arrow() { return <span className="arrow" aria-hidden="true">↗</span> }

function CommandBar({ open, onClose, query, setQuery, onSelect }) {
	if (!open) return null
	const matches = projects.filter((project) => `${project.title} ${project.type} ${project.tags.join(' ')}`.toLowerCase().includes(query.toLowerCase()))
	return <div className="command-backdrop" onClick={onClose}><div className="command-bar" onClick={(event) => event.stopPropagation()} role="dialog" aria-modal="true" aria-label="Project command palette"><div className="command-input"><span>⌘</span><input autoFocus value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Find a project, tool, or thought..." /><kbd>ESC</kbd></div><div className="command-results">{matches.length ? matches.map((project) => <button key={project.id} onClick={() => onSelect(project)}><span className="command-dot" style={{ background: project.color }} />{project.title}<small>{project.type}</small><Arrow /></button>) : <p>No signal found. Try React, Product, or Motion.</p>}</div><div className="command-hint"><span>Navigate with arrows</span><span>Enter to open</span></div></div></div>
}

function ProjectCard({ project, onOpen, active }) {
	return <button className={`project-card ${active ? 'is-active' : ''}`} onClick={() => onOpen(project)} style={{ '--accent': project.color }}><div className="project-visual"><video src={project.video} poster={project.media} autoPlay loop muted playsInline /><span className="project-number">{project.number}</span><span className="media-label">Play case study ↗</span></div><div className="card-copy"><div className="card-top"><span>{project.type}</span><span>{project.year}</span></div><h3>{project.title}</h3><p>{project.summary}</p><div className="card-bottom"><div className="mini-tags">{project.tags.map((tag) => <span key={tag}>{tag}</span>)}</div><Arrow /></div></div></button>
}

function CasePanel({ project, onClose }) {
	return <div className="case-backdrop" onClick={onClose}><aside className="case-panel" onClick={(event) => event.stopPropagation()} style={{ '--accent': project.color }}><button className="close-button" onClick={onClose} aria-label="Close project details">Close <span>×</span></button><p className="eyebrow">Case study / {project.number}</p><div className="case-media"><img src={project.media} alt={`${project.title} case study`} />{project.video && <video src={project.video} poster={project.media} autoPlay loop muted playsInline />}</div><div className="case-meta"><span>{project.type}</span><span>{project.year}</span></div><h2>{project.title}</h2><p className="case-detail">{project.detail}</p><div className="case-result"><span>Signal</span><strong>{project.result}</strong></div><div className="case-stack">{project.tags.map((tag) => <span key={tag}>{tag}</span>)}</div><a className="case-link" href="mailto:hello@mona.dev">Ask me about this project <Arrow /></a></aside></div>
}

function VisualReel() {
	return <section className="reel-section"><div className="reel-heading"><div><p className="eyebrow">02 — Visual reel</p><h2>Work you can<br /><em>feel.</em></h2></div><p>Selected frames, motion studies, and the texture behind the interfaces.</p></div><div className="reel-grid"><div className="reel-video"><video key="latest-mona-reel" src="/media/mona-visual-reel.mp4?v=2" poster="https://images.unsplash.com/photo-1515879218367-8466d910aaa4?auto=format&fit=crop&w=1200&q=85" autoPlay loop muted playsInline /><span>Original studio reel / Mona</span></div><figure><img src="https://images.unsplash.com/photo-1558655146-d09347e92766?auto=format&fit=crop&w=900&q=85" alt="Design sketches and interface notes" /><figcaption>Interface research / Berlin</figcaption></figure><figure><img src="https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=900&q=85" alt="Retro technology inspiration" /><figcaption>Material study / 03</figcaption></figure></div></section>
}

function PhoneShowcase() {
	return <section className="phone-showcase"><div className="phone-copy"><p className="eyebrow">03 — On the small screen</p><h2>Big ideas.<br /><em>Small frame.</em></h2><p>The same interface, art-directed for the phone. A live product preview, a little code, and the detail that makes the interaction feel intentional.</p><div className="phone-meta"><span><i /> Live prototype</span><span>React / 60fps</span></div></div><div className="phone-scene"><div className="code-float"><span><b>01</b> const signal =</span><span><b>02</b> createExperience( )</span><span><b>03</b> await launch( )</span></div><div className="phone-device"><div className="phone-speaker" /><div className="phone-screen"><video src="/media/mona-motion-piece.mp4" autoPlay loop muted playsInline /><div className="phone-ui"><div className="phone-ui-top"><span>MONA / 01</span><span>MENU</span></div><div className="phone-ui-title">Make the<br /><em>web alive.</em></div><div className="phone-ui-card"><span>SELECTED WORK</span><strong>Morrow</strong><small>Product system · 2024</small><i>↗</i></div><div className="phone-ui-bottom">Scroll to explore ↓</div></div></div></div><div className="phone-orbit orbit-left" /><div className="phone-orbit orbit-right" /></div></section>
}

function SignalLab() {
	const [intensity, setIntensity] = useState(68)
	const [isCalm, setIsCalm] = useState(false)
	return <section className="lab-section" id="lab"><div className="lab-copy"><p className="eyebrow">03 — A small experiment</p><h2>Design is a<br /><em>living system.</em></h2><p>Play with the signal. This tiny canvas uses the same primitives I reach for in production: state, input, composition, and a little restraint.</p></div><div className={`signal-lab ${isCalm ? 'calm' : ''}`} style={{ '--intensity': `${intensity}%` }}><div className="lab-orbit orbit-a" /><div className="lab-orbit orbit-b" /><div className="lab-orbit orbit-c" /><div className="lab-core"><span>{intensity}</span><small>signal</small></div><label>Intensity <input type="range" min="20" max="100" value={intensity} onChange={(event) => setIntensity(event.target.value)} /></label><button className="calm-toggle" onClick={() => setIsCalm(!isCalm)}>{isCalm ? 'Wake the system' : 'Find the quiet'}</button></div></section>
}

function ContactForm() {
	const [fields, setFields] = useState({ name: '', phone: '', whatsapp: '', brief: '' })
	const [isWriting, setIsWriting] = useState(false)
	const updateField = (event) => setFields({ ...fields, [event.target.name]: event.target.value })
	return <section className={`contact-section ${isWriting ? 'is-writing' : ''}`} id="contact"><div className="contact-intro"><p className="eyebrow">06 — Start a conversation</p><h2>Bring me<br /><em>the brief.</em></h2><p>Tell me what you are building. The little cloud is listening while you write.</p><div className="contact-cloud cloud-one" /><div className="contact-cloud cloud-two" /><div className="contact-cloud cloud-three" /></div><form className="contact-form" onSubmit={(event) => event.preventDefault()} onFocus={() => setIsWriting(true)} onBlur={() => setIsWriting(false)}><label><span>Your name</span><input name="name" value={fields.name} onChange={updateField} placeholder="Mona..." required /></label><label><span>Phone number</span><input name="phone" value={fields.phone} onChange={updateField} placeholder="+20 10 0000 0000" type="tel" /></label><label><span>WhatsApp</span><input name="whatsapp" value={fields.whatsapp} onChange={updateField} placeholder="WhatsApp number or link" /></label><label className="wide-field"><span>What are we making?</span><textarea name="brief" value={fields.brief} onChange={updateField} placeholder="A product, a brand, a world..." rows="3" /></label><button className="send-button" type="submit">Send the signal <Arrow /></button></form></section>
}

function App() {
	const [filter, setFilter] = useState('All')
	const [selectedProject, setSelectedProject] = useState(null)
	const [commandOpen, setCommandOpen] = useState(false)
	const [query, setQuery] = useState('')
	const [menuOpen, setMenuOpen] = useState(false)
	const [cursor, setCursor] = useState({ x: 50, y: 50 })
	const visibleProjects = useMemo(() => filter === 'All' ? projects : projects.filter((project) => filter === 'Product' ? project.type === 'Product system' : project.type !== 'Product system'), [filter])

	useEffect(() => {
		const handleKey = (event) => { if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') { event.preventDefault(); setCommandOpen(true) } if (event.key === 'Escape') { setCommandOpen(false); setSelectedProject(null) } }
		window.addEventListener('keydown', handleKey)
		return () => window.removeEventListener('keydown', handleKey)
	}, [])

	const openProject = (project) => { setSelectedProject(project); setCommandOpen(false); setQuery('') }
	return <main className="app-shell" style={{ '--cursor-x': `${cursor.x}%`, '--cursor-y': `${cursor.y}%` }} onPointerMove={(event) => setCursor({ x: (event.clientX / window.innerWidth) * 100, y: (event.clientY / window.innerHeight) * 100 })}><div className="cursor-glow" aria-hidden="true" /><header className="topbar"><a className="brand" href="#top"><span className="brand-mark">M</span><span>MONA / 01</span></a><div className={`nav-menu ${menuOpen ? 'open' : ''}`}><a href="#work" onClick={() => setMenuOpen(false)}>Work <sup>06</sup></a><a href="#lab" onClick={() => setMenuOpen(false)}>Lab <sup>01</sup></a><a href="#about" onClick={() => setMenuOpen(false)}>About</a></div><div className="top-actions"><button className="command-trigger" onClick={() => setCommandOpen(true)}><span>Search archive</span><kbd>Ctrl K</kbd></button><button className="menu-trigger" onClick={() => setMenuOpen(!menuOpen)}>{menuOpen ? 'Close' : 'Menu'}</button><span className="availability"><i /> Open to work</span></div></header>

		<section className="intro-section" id="top"><div className="intro-left"><p className="eyebrow">Cairo / working globally / 2024</p><h1>I make the<br /><em>web feel alive.</em></h1><p className="intro-text">Frontend engineer and product thinker building interfaces that turn complexity into something people want to touch.</p><div className="intro-actions"><a className="primary-action" href="#work">Explore the work <Arrow /></a><a className="quiet-action" href="#about">What I believe ↓</a></div></div><div className="intro-right"><div className="system-card"><div className="system-header"><span><i className="status-dot" /> Live canvas</span><span>01 / 03</span></div><div className="system-visual"><div className="scanlines" /><div className="system-orbit orbit-one" /><div className="system-orbit orbit-two" /><div className="system-orbit orbit-three" /><div className="system-monogram">M<span>↗</span></div><div className="system-coordinates">30° 02' N<br />31° 14' E</div></div><div className="system-footer"><span>Move your cursor</span><strong>to shift the signal</strong></div></div><span className="vertical-label">REACT / MOTION / SYSTEMS</span></div><div className="scroll-cue"><span>Scroll to explore</span><i /></div></section>

		<section className="manifesto" id="about"><p className="eyebrow">A working philosophy</p><p className="manifesto-text">The best interfaces do not shout. They <em>respond.</em> They give people a sense of where they are, what matters, and what might happen next.</p><span className="manifesto-mark">✳</span></section>
		<section className="work-section" id="work"><div className="section-header"><div><p className="eyebrow">01 — Selected work</p><h2>Built with <em>intent.</em></h2></div><p className="section-description">Not decoration. Systems with a point of view, made for products that need to move.</p></div><div className="work-toolbar"><div className="filter-tabs">{filters.map((item) => <button className={filter === item ? 'active' : ''} key={item} onClick={() => setFilter(item)}>{item}</button>)}</div><span>{visibleProjects.length.toString().padStart(2, '0')} signals found</span></div><div className="projects-grid">{visibleProjects.map((project) => <ProjectCard key={project.id} project={project} onOpen={openProject} active={selectedProject?.id === project.id} />)}</div></section>
		<VisualReel />
		<PhoneShowcase />
		<SignalLab />
		<section className="experience-section"><div><p className="eyebrow">04 — The long view</p><h2>Years of<br /><em>making.</em></h2></div><div className="experience-list"><div><span>2024 — now</span><strong>Independent product engineer</strong><p>Partnering with teams to turn early ideas into clear, shipped experiences.</p></div><div><span>2021 — 2024</span><strong>Frontend engineer / studio lead</strong><p>Built digital products, led launches, and made systems that outlived the pitch deck.</p></div><div><span>2019 — 2021</span><strong>Designer who learned to code</strong><p>Started with the pixels, stayed for the interaction, and never looked back.</p></div></div></section>
		<section className="principles-section"><p className="eyebrow">05 — The toolkit</p><div className="principles-grid"><div><span>01</span><h3>Make it legible.</h3><p>Accessibility is not a checklist. It is respect for the person on the other side of the screen.</p></div><div><span>02</span><h3>Earn the motion.</h3><p>Every transition should carry information, not just make the page wiggle.</p></div><div><span>03</span><h3>Ship the feeling.</h3><p>Performance, craft, and a clear point of view are part of the same job.</p></div></div></section>
		<ContactForm />
		<footer className="footer"><div><p className="eyebrow">Open channel</p><h2>Let's make<br /><em>the good stuff.</em></h2></div><div className="footer-right"><a className="email-link" href="mailto:hello@mona.dev">hello@mona.dev <Arrow /></a><p>Available for product teams, studios,<br />and ideas with a little voltage.</p><div className="footer-links"><a href="https://github.com" target="_blank" rel="noreferrer">GitHub ↗</a><a href="https://www.linkedin.com" target="_blank" rel="noreferrer">LinkedIn ↗</a></div></div><div className="footer-bottom"><span>© 2024 Mona</span><span>Designed and built in React</span><a href="#top">Back to top ↑</a></div></footer>
		<CommandBar open={commandOpen} onClose={() => setCommandOpen(false)} query={query} setQuery={setQuery} onSelect={openProject} />{selectedProject && <CasePanel project={selectedProject} onClose={() => setSelectedProject(null)} />}
	</main>
}

export default App